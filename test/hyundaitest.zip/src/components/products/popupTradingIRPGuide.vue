<template>
<div id="tradingIRPGuide" class="fullPopup">
    <!-- IRP 상품매매 이용안내 -->
    <div class="header">
        <h1>IRP 상품매매 이용안내</h1>
        <button class="modalClose" @click="returnVal(false)"></button>
    </div>
</div>
</template>