<template>
    <h1>공통디자인-Button</h1>
    <h2>버튼공통 size</h2>
    <h3>기본</h3>
    <button class="h32">확인</button>
    <button>확인</button>
    <button class="h44">확인</button>
    <button class="h50">확인</button>
    <button class="h50" disabled>확인</button>
    <h3>black</h3>
    <button class="h32 black">확인</button>
    <button class="black">확인</button>
    <button class="h44 black">확인</button>
    <button class="h50 black">확인</button>
    <button class="h50 black" disabled>확인</button>
    <h3>red</h3>
    <button class="h32 red">확인</button>
    <button class="red">확인</button>
    <button class="h44 red">현금매도</button>
    <button class="h50 red">확인</button>
    <button class="h50 red" disabled>확인</button>
    <h3>blue</h3>
    <button class="h44 blue">현금매도</button>
    <button class="h44 blue" disabled>현금매도</button>
    <h3>pointBlue</h3>
    <button class="h44 pointBlue">현금</button>
    <button class="h44 pointBlue" disabled>확인</button>
    <h3>white</h3>
    <button class="h44 white">현금</button>
    <button class="h44 white" disabled>취소</button>
    <h3>gray - 선택버튼</h3>
    <button class="gray">현금</button>
    <button class="gray" disabled>현금</button>
</template>
