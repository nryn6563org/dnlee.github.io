<template>
<div>
    <p>타이틀</p>
    <h3>h3기본값 - 폰트사이즈 16px, 굵기 700 </h3>
    <p> ul.checkBoxList</p>
    <ul class="checkBoxList">
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol>
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
            <!-- 버튼영역 -->
            <div>
                <button type="button" class="fontBlue">버튼1</button>
            </div>
        </li>
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol>
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
            <!-- 버튼영역 -->
            <div>
                <button type="button" class="fontBlue">버튼1</button>
                <button type="button" class="fontRed">버튼2</button>
            </div>
        </li>
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol>
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
            <!-- 버튼영역 -->
            <div>
                <button type="button" class="fontBlue">버튼1</button>
                <button type="button" >버튼2</button>
                <button type="button" class="fontRed">버튼3</button>
            </div>
        </li>
    </ul>
    <p> ul.checkBoxList.noCheck</p>
    <ul class="checkBoxList noCheck">
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol>
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
            <!-- 버튼영역 -->
            <div>
                <button type="button" class="fontBlue">버튼1</button>
            </div>
        </li>
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol>
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
        </li>
    </ul>
    <p>체크박스 리스트 버튼없는경우</p>
    <ul class="checkBoxList">
        <li>
            <!-- 체크박스포함 txt영역 -->
            <label for="select01">
                <input type="checkbox" id="select01">
                <div>
                    <span class="bullet lightBlue">보통위험</span>
                    <span class="bullet gray">원리금보장</span>
                    <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
                </div>
            </label>
            <!-- 하위목록영역 -->
            <ol class="simpleBox">
                <li>
                    <span>기본</span>
                    <strong class="fontRed">기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
                <li>
                    <span>기본</span>
                    <strong>기본</strong>
                </li>
            </ol>
        </li>
    </ul>
    <p>ul.accordionList </p>
    <!-- 기본 -->
    <ul class="accordionList">
        <li class="on">
            <!-- 텍스트영역 -->
            <div>
                <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
            </div>
            <!-- 하위목록영역 -->
            <ol class="squareBox">
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
            </ol>
        </li>
        <li class="on">
            <!-- 텍스트영역 -->
            <div>
                <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]</h2>
            </div>
            <!-- 하위목록영역 -->
            <ol class="squareBox">
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
            </ol>
        </li>
        <li class="on">
            <!-- 텍스트영역 -->
            <div>
                <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]<span class="bullet red">위험자산</span></h2>
            </div>
            <!-- 하위목록영역 -->
            <ol class="squareBox">
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
                <li>
                    <span>기본</span>
                    <p>기본</p>
                </li>
            </ol>
        </li>
        <li class="on">
            <!-- 텍스트영역 -->
            <div>
                <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]<span class="bullet lightBlue">적합</span></h2>
                <p class="fontPointBlue">매수신청</p>
            </div>
            <!-- 하위목록영역 -->
            <ol class="squareBox hasMore">
                <li>
                    <span>hasMore</span>
                    <p>hasMore</p>
                </li>
                <li>
                    <span>hasMore</span>
                    <p>hasMore</p>
                </li>
                <li>
                    <span>hasMore</span>
                    <p>hasMore</p>
                </li>
            </ol>
        </li>
        <!-- 오류메세지 .erro -->
        <li class="erro">
            <!-- 텍스트영역 -->
            <div>
                <h2>NH-Amundi코리아2배인버스레버리지증권투자신탁[주식-파생재간접형]<span class="bullet red">부적합</span></h2>
                <p class="fontRed">오류메시지 출력</p>
            </div>
        </li>
    </ul>
    <p>.simpleBox : bg, 여백no</p>
    <ul class="simpleBox">
        <li>
            <span>오류메시지 출력</span>
            <p>가입일 <span>2022.08.12</span></p>
        </li>
        <li>
            <span>가입신청</span>
            <p>가입일 <span>2022.08.12</span></p>
        </li>
    </ul>
    <p>ul.squareBox </p>
    <ul class="squareBox">
        <li>
            <strong>타이틀</strong>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
    </ul>
    <p>ul.roundBox </p>
    <!-- 기본 -->
    <ul class="roundBox">
        <!-- 요소가 1개일때 -->
        <li>
            <span>단일기본</span>
        </li>
        <li>
            <strong>단일 & 굵기500</strong>
        </li>
        <!-- 멀티라인 -->
        <li>
            <span>멀티라인1<br>멀티라인2</span>
            <p>싱글라인</p>
        </li>
        <li>
            <span>1멀티라인<br>2멀티라인</span>
            <p>3멀티라인<br>4멀티라인</p>
        </li>
        <!-- 폰트굵기 500일때 strong -->
        <li>
            <span>폰트굵기400</span>
            <strong class="fontRed ">폰트굵기 500 & 컬러</strong>
        </li>
        <!-- 기본 -->
        <li>
            <span>기본 span</span>
            <p>싱글라인기본 p태그 </p>
        </li>
        <li>
            <span>기본</span>
            <p>싱글라인기본</p>
        </li>
    </ul>
    <br><br>
    <!-- 구분선 -->
    <ul class="roundBox">
        <li>
            <span class="fontBlue">블루</span>
            <strong>폰트굵기500</strong>
        </li>
        <hr>
        <li>
            <strong>1.폰트500</strong>
            <p>기본</p>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
        <!-- 구분선 hr -->
        <hr>
        <li>
            <strong>2.단일 폰트500</strong>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
        <!-- 구분선 hr -->
        <hr>
        <li>
            <span>기본</span>
            <strong>폰트굵기500</strong>
        </li>
        <li>
            <span>기본</span>
            <strong>폰트굵기500</strong>
        </li>
        <li>
            <span>기본</span>
            <strong class="fontPointBlue">폰트굵기500 & 컬러블루</strong>
        </li>
    </ul>
    <br><br>
    <!-- 하위로 떨어지는 영역 - 셀렉트 버튼 -->
    <ul class="roundBox">
        <li>
            <span>기본</span>
            <p>기본</p>
            <!-- 하위로 떨어지는 영역 -->
            <div class="wrapArea">
                <button class="select">셀렉트버튼</button>
                <button class="select">셀렉트버튼</button>
            </div>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
            <div class="wrapArea">
                <button class="select">셀렉트버튼</button>
            </div>
        </li>
        <li>
            <span>기본</span>
            <p>기본</p>
        </li>
    </ul>
    <br><br>
    <p>ul.roundBox.innerList</p>
    <!-- 중첩리스트 -->
    <ul class="roundBox innerList">
        <li>
            <span>기본</span>
            <strong>굵기500</strong>
        </li>
        <li>
            <span>기본</span>
            <strong>굵기500</strong>
        </li>
        <li>
            <span>기본</span>
            <strong>굵기500</strong>
            <ol>
                <li>
                    <span>중첩리스트</span>
                    <strong>굵기</strong>
                </li>
                <li>
                    <span>중첩리스트<br>중첩리스트 멀티</span>
                    <strong>굵기</strong>
                </li>
            </ol>
        </li>
    </ul>
    <br><br>
    <p> ul.roundBox.bulletList</p>
    <!-- 불렛리스트 -->
    <ul class="roundBox bulletList">
        <li class="title">목록 타이틀</li>
        <li>IRP는 ETF/리츠 매매에 사용할 매매한도를 사전에 설정하고, 설정한 금액 내에서 매매 가능합니다.</li>
        <li>설정한 한도 금액은 다른 상품의 매매, 지급액(연금지급 포함)으로 사용할 수 없습니다.</li>
    </ul>
    <p>타이틀없는 불렛목록</p>
    <ul class="roundBox bulletList">
        <!-- <li class="title">목록 타이틀</li> -->
        <li>IRP는 ETF/리츠 매매에 사용할 매매한도를 사전에 설정하고, 설정한 금액 내에서 매매 가능합니다.</li>
        <li>설정한 한도 금액은 다른 상품의 매매, 지급액(연금지급 포함)으로 사용할 수 없습니다.</li>
    </ul>
</div>
</template>