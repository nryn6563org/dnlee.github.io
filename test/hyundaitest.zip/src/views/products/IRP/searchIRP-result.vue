<template>
<div>
    <!-- IRP 검색 -->
    <section>
        결과
    </section>
    <div class="buttonArea">
        <button type="button" class="white h50">
            IRP 거래내역/취소
        </button>
        <button type="button" class="pointBlue h50">
            확인
        </button>
    </div>
</div>
</template>
<script setup>

</script>
<style lang="postcss" scoped>

</style>