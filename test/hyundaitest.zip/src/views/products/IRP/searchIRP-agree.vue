<template>
<div>
    <!-- IRP 검색 -->
    <section>
        동의
    </section>
    <div class="buttonArea div3_7">
        <button type="button" class="white h50">
            이전
        </button>
        <button type="button" class="pointBlue h50">
            다음
        </button>
    </div>
</div>
</template>
<script setup>

</script>
<style lang="postcss" scoped>

</style>